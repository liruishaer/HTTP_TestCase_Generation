** LIST OF FOLDERS AND FILES **


Pattern catalog and coding
----------------------

* pattern_catalog.xlsx: contains the discourse pattern catalog

* Bug_coding_criteria.pdf: contains the criteria for bug report coding

